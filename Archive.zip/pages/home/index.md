---
title: React Static Boilerplate
---

## Welcome!

This is a single-page application powered by React and Material Design Lite (MDL).

https://github.com/kriasoft/react-static-boilerplate

